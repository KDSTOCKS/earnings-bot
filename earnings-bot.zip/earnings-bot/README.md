# earnings-bot

Watches a list of tickers. When one reports new quarterly numbers, it posts
a revenue + EPS chart to X automatically. Runs for free on GitHub Actions —
no server to maintain.

## One-time setup

1. **Create a private GitHub repo** and upload everything in this folder to it
   (keeping the `.github/workflows/` path intact).

2. **Get a free Financial Modeling Prep API key** at
   https://site.financialmodelingprep.com/ (free tier is enough for a handful
   of tickers checked every couple hours).

3. **Add secrets** in your repo: Settings → Secrets and variables → Actions →
   New repository secret. Add all five:
   - `FMP_API_KEY`
   - `X_API_KEY`
   - `X_API_SECRET`
   - `X_ACCESS_TOKEN`
   - `X_ACCESS_SECRET`

4. **Enable Actions** on the repo (Actions tab → "I understand, enable
   workflows" if prompted). The workflow runs every 2 hours by default — edit
   the `cron` line in `.github/workflows/check-earnings.yml` to change that.

5. **Add tickers** using `ticker-manager.html` (open it in any browser) — or
   just edit `tickers.json` directly on GitHub, e.g.:
   ```json
   ["AAPL", "NVDA", "MSFT"]
   ```

That's it. Every run, the bot checks each ticker's latest reported quarter
against `posted.json`. If it's new, it builds the chart and posts it, then
commits the update back to `posted.json` so it won't post the same quarter
twice.

## Testing it

Go to the Actions tab → "Check earnings and post" → "Run workflow" to trigger
it by hand instead of waiting for the schedule. Check the run's logs to see
what it found.

## Notes

- Financial Modeling Prep's exact field names can shift between plan tiers —
  if a ticker comes back with $0 revenue/EPS, check the raw API response for
  that ticker and adjust the field names in `check_earnings.py`.
- X's API is pay-per-use now (roughly a couple cents per post with an image),
  so make sure billing is attached to your X Developer account.
- The chart shows the last 6 quarters by default — change `QUARTERS_SHOWN` in
  `check_earnings.py` to show more or fewer.
